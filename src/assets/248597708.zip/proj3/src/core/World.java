package core;

import tileengine.TERenderer;
import tileengine.TETile;
import tileengine.Tileset;
import edu.princeton.cs.algs4.StdDraw;
import utils.FileUtils;

import java.io.IOException;
import java.util.Random;
import java.io.File;

import static java.lang.Character.isDigit;

public class World {

    // build your own world!
    public enum WorldObjectType {
        Room,
        Hall
    }

    private long seed;

    // width is x-value
    private int width;

    // height is y-value
    private int height;

    private long lastFrameTime;

    private TETile[][] tiles;
    private TETile[][] visibleTiles;

    private TERenderer ter;

    private Avatar player;

    private String saveFilePath = "save-file.txt";

    private boolean lineOfSightMode = false;

    private static final int DEFAULT_WIDTH = 100;
    private static final int DEFAULT_HEIGHT = 50;

    public World(int width, int height) {
        this.seed = seed;
        this.width = width;
        this.height = height;
        visibleTiles = new TETile[width][height];
        resetVisibleTiles();
        ter = new TERenderer();
    }

    public void getWorldFromSeed(long seedInput) {
        WorldGenerator worldGen = new WorldGenerator();
        this.seed = seedInput;
        tiles = worldGen.generateWorld(seed, width, height);
        Random nextgen2 = new Random(seed);
        int avatarX = 0;
        int avatarY = 0;
        while (tiles[avatarX][avatarY] != Tileset.FLOOR) {
            avatarX = nextgen2.nextInt(this.width);
            avatarY = nextgen2.nextInt(this.height);
        }
        tiles[avatarX][avatarY] = Tileset.AVATAR;
        player = new Avatar(avatarX, avatarY);
    }
    public long getSeed() {
        return seed;
    }

    public World() {
        this(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    public long seedMenu() {
        String result = "";
        ter.initialize(20, 20);
        StdDraw.setPenColor(255, 255, 255);
        StdDraw.text(10, 15, "Enter seed here:");
        StdDraw.show();
        boolean inMenu = true;
        while (inMenu) {
            if (StdDraw.hasNextKeyTyped()) {
                char nextChar = Character.toLowerCase(StdDraw.nextKeyTyped());
                if (nextChar == 's') {
                    inMenu = false;
                }
                if (isDigit(nextChar)) {
                    result += nextChar;
                    drawInput(result);
                }
            }
        }
        long seedInput = Long.parseLong(result);
        return seedInput;
    }
    private void drawInput(String input) {
        StdDraw.clear(StdDraw.BLACK);
        StdDraw.setPenColor(255, 255, 255);
        StdDraw.text(10, 10, input);
        StdDraw.text(10, 15, "Enter seed here:");
        StdDraw.show();
    }

    public void drawMenu() {
        ter.initialize(30, 40);
        StdDraw.setPenColor(255, 255, 255);
        StdDraw.text(15, 30, "CS61B: THE GAME");
        StdDraw.text(15, 20, "New Game (N)");
        StdDraw.text(15, 19, "Load Game (L)");
        StdDraw.text(15, 18, "Quit (Q)");
        StdDraw.show();
    }



    public void runGame() {
        drawMenu();
        boolean inMenu = true;
        while (inMenu) {
            if (StdDraw.hasNextKeyTyped()) {
                char key = Character.toLowerCase(StdDraw.nextKeyTyped());
                switch (key) {
                    case 'n':
                        long seedInput = seedMenu();
                        getWorldFromSeed(seedInput);
                        inMenu = false;
                        break;
                    case 'l':
                        loadWorldFromFile();
                        inMenu = false;
                        break;
                    case 'q':
                        System.exit(0);
                        break;
                    default:
                        break;
                }
            }
        }
        initializeWorld();
        lineOfSightMode = false;
        boolean inGame = true;
        boolean typedColon = false;
        if (lineOfSightMode) {
            updateVisibleTiles();
        }
        while (inGame) {
            if (frameTimeDelta() > 50) {
                updateFrameTime();
                if (StdDraw.hasNextKeyTyped()) {
                    char key = Character.toLowerCase(StdDraw.nextKeyTyped());
                    if (key == ':') {
                        typedColon = true;
                    } else if (key == 'r') {
                        runGame();
                    } else if (typedColon && (key == 'q')) {
                        saveWorldToFile();
                        System.exit(0);
                    } else {
                        typedColon = false;
                    }
                    updateWorld(key);
                }
                if (lineOfSightMode) {
                    updateVisibleTiles();
                }
                drawWorld();
                renderHUD();
            }
        }
    }

    public void initializeWorld() {
        ter.initialize(width, height + 1);
    }

    public void drawWorld() {
        if (lineOfSightMode) {
            ter.renderFrame(visibleTiles);
        } else {
            ter.renderFrame(tiles);
        }
    }

    private void move(char direction) {
        int deltaX = 0;
        int deltaY = 0;
        switch (direction) {
            case 'a':
                deltaX = -1;
                break;
            case 's':
                deltaY = -1;
                break;
            case 'd':
                deltaX = 1;
                break;
            case 'w':
                deltaY = 1;
                break;
            default:
                break;
        }
        if (tiles[player.x() + deltaX][player.y() + deltaY].equals(Tileset.FLOOR)) {
            player.moveAvatar(deltaX, deltaY);
        }
    }

    public TETile[][] getTiles() {
        return tiles;
    }

    public void updateWorld(char input) {
        if (input == 'w' | input == 'a' | input == 's' | input == 'd') {
            int x = player.x();
            int y = player.y();
            tiles[x][y] = Tileset.FLOOR;
            move(input);
            int newPosX = player.x();
            int newPosY = player.y();
            tiles[newPosX][newPosY] = Tileset.AVATAR;
        } else if (input == 'v') {
            lineOfSightMode = !lineOfSightMode;
        }
    }

    public void saveWorldToFile() {
        // Tileset.NOTHING = 0
        // Tileset.FLOOR = 1
        // Tileset.WALL = 2
        // Tileset.AVATAR = 3
        String contents = width + " " + height + "\n";
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (tiles[x][y].equals(Tileset.NOTHING)) {
                    contents += 0;
                } else if (tiles[x][y].equals(Tileset.FLOOR)) {
                    contents += 1;
                } else if (tiles[x][y].equals(Tileset.WALL)) {
                    contents += 2;
                } else if (tiles[x][y].equals(Tileset.AVATAR)) {
                    contents += 3;
                }
            }
            contents += "\n";
        }
        if (!FileUtils.fileExists(saveFilePath)) {
            File saveFile = new File(saveFilePath);
            try {
                saveFile.createNewFile();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
        FileUtils.writeFile(saveFilePath, contents);
    }

    public void loadWorldFromFile() {
        // Tileset.NOTHING = 0
        // Tileset.FLOOR = 1
        // Tileset.WALL = 2
        // Tileset.AVATAR = 3
        String contents = FileUtils.readFile(saveFilePath);
        String[] splitContents = contents.split("\n");
        String[] dimensions = splitContents[0].split(" ");
        this.width = Integer.parseInt(dimensions[0]);
        this.height = Integer.parseInt(dimensions[1]);
        tiles = new TETile[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                char current = splitContents[x + 1].charAt(y);
                switch (current) {
                    case '0':
                        tiles[x][y] = Tileset.NOTHING;
                        break;
                    case '1':
                        tiles[x][y] = Tileset.FLOOR;
                        break;
                    case '2':
                        tiles[x][y] = Tileset.WALL;
                        break;
                    case '3':
                        tiles[x][y] = Tileset.AVATAR;
                        player = new Avatar(x, y);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private void updateVisibleTiles() {
        resetVisibleTiles();
        makeTileVisible(player.x(), player.y());
        exploreVisibleLeft();
        exploreVisibleRight();
        exploreVisibleDown();
        exploreVisibleUp();
    }

    private void exploreVisibleRight() {
        // Explore +x
        int playerX = player.x();
        int playerY = player.y();
        int distance = 1;
        boolean inHallway = false;
        int hallwayExitX = playerX;
        int exploreX = playerX + 1;
        int exploreY = playerY;
        int visibleStartY = exploreY;
        int visibleEndY = exploreY;
        while (!tiles[exploreX][exploreY].equals(Tileset.WALL)) {
            if (tiles[exploreX][exploreY + 1].equals(Tileset.WALL)
                    && tiles[exploreX][exploreY - 1].equals(Tileset.WALL)) {
                inHallway = true;
                visibleStartY = exploreY;
                visibleEndY = exploreY;
            } else {
                if (inHallway) {
                    inHallway = false;
                    distance = exploreX - playerX;
                    hallwayExitX = exploreX;
                }
            }
            if (exploreX >= hallwayExitX && ((exploreX - hallwayExitX) % distance == 0)) {
                if (!tiles[exploreX][visibleEndY + 1].equals(Tileset.WALL)) {
                    visibleEndY += 1;
                }
                if (!tiles[exploreX][visibleStartY - 1].equals(Tileset.WALL)) {
                    visibleStartY -= 1;
                }
            }
            if (tiles[exploreX - 1][visibleStartY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][visibleStartY].equals(Tileset.WALL)) {
                visibleStartY += 1;
            }
            if (tiles[exploreX - 1][visibleEndY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][visibleEndY].equals(Tileset.WALL)) {
                visibleEndY -= 1;
            }
            for (int y = visibleStartY; y <= visibleEndY; y++) {
                makeTileVisible(exploreX, y);
            }
            exploreX += 1;
        }
    }
    private void exploreVisibleLeft() {
        // Explore -x
        int playerX = player.x();
        int playerY = player.y();
        boolean inHallway = false;
        int distance = 1;
        int hallwayExitX = playerX;
        int exploreX = playerX - 1;
        int exploreY = playerY;
        int visibleStartY = exploreY;
        int visibleEndY = exploreY;
        while (!tiles[exploreX][exploreY].equals(Tileset.WALL)) {
            if (tiles[exploreX][exploreY + 1].equals(Tileset.WALL)
                    && tiles[exploreX][exploreY - 1].equals(Tileset.WALL)) {
                inHallway = true;
                visibleStartY = exploreY;
                visibleEndY = exploreY;
            } else {
                if (inHallway) {
                    inHallway = false;
                    distance = playerX - exploreX;
                    hallwayExitX = exploreX;
                }
            }
            if (exploreX <= hallwayExitX && ((hallwayExitX - exploreX) % distance == 0)) {
                if (!tiles[exploreX][visibleEndY + 1].equals(Tileset.WALL)) {
                    visibleEndY += 1;
                }
                if (!tiles[exploreX][visibleStartY - 1].equals(Tileset.WALL)) {
                    visibleStartY -= 1;
                }
            }
            if (tiles[exploreX - 1][visibleStartY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][visibleStartY].equals(Tileset.WALL)) {
                visibleStartY += 1;
            }
            if (tiles[exploreX - 1][visibleEndY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][visibleEndY].equals(Tileset.WALL)) {
                visibleEndY -= 1;
            }
            for (int y = visibleStartY; y <= visibleEndY; y++) {
                makeTileVisible(exploreX, y);
            }
            exploreX -= 1;
        }

    }
    private void exploreVisibleUp() {
        // Explore +y
        int playerX = player.x();
        int playerY = player.y();
        int distance = 1;
        boolean inHallway = false;
        int hallwayExitY = playerY;
        int exploreX = playerX;
        int exploreY = playerY + 1;
        int visibleStartX = exploreX;
        int visibleEndX = exploreX;
        while (!tiles[exploreX][exploreY].equals(Tileset.WALL)) {
            if (tiles[exploreX - 1][exploreY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][exploreY].equals(Tileset.WALL)) {
                inHallway = true;
                visibleStartX = exploreX;
                visibleEndX = exploreX;
            } else {
                if (inHallway) {
                    inHallway = false;
                    distance = exploreY - playerY;
                    hallwayExitY = exploreY;
                }
            }
            if (exploreY >= hallwayExitY && ((exploreY - hallwayExitY) % distance == 0)) {
                if (!tiles[visibleEndX + 1][exploreY].equals(Tileset.WALL)) {
                    visibleEndX += 1;
                }
                if (!tiles[visibleStartX - 1][exploreY].equals(Tileset.WALL)) {
                    visibleStartX -= 1;
                }
            }
            if (tiles[visibleStartX][exploreY - 1].equals(Tileset.WALL)
                    && tiles[visibleStartX][exploreY + 1].equals(Tileset.WALL)) {
                visibleStartX += 1;
            }
            if (tiles[visibleEndX][exploreY - 1].equals(Tileset.WALL)
                    && tiles[visibleEndX][exploreY + 1].equals(Tileset.WALL)) {
                visibleEndX -= 1;
            }
            for (int x = visibleStartX; x <= visibleEndX; x++) {
                makeTileVisible(x, exploreY);
            }
            exploreY += 1;
        }
    }
    private void exploreVisibleDown() {
        // Explore -y
        int playerX = player.x();
        int playerY = player.y();
        int distance = 1;
        boolean inHallway = false;
        int hallwayExitY = playerY;
        int exploreX = playerX;
        int exploreY = playerY - 1;
        int visibleStartX = exploreX;
        int visibleEndX = exploreX;
        while (!tiles[exploreX][exploreY].equals(Tileset.WALL)) {
            if (tiles[exploreX - 1][exploreY].equals(Tileset.WALL)
                    && tiles[exploreX + 1][exploreY].equals(Tileset.WALL)) {
                inHallway = true;
                visibleStartX = exploreX;
                visibleEndX = exploreX;
            } else {
                if (inHallway) {
                    inHallway = false;
                    distance = playerY - exploreY;
                    hallwayExitY = exploreY;
                }
            }
            if (exploreY <= hallwayExitY && ((hallwayExitY - exploreY) % distance == 0)) {
                if (!tiles[visibleEndX + 1][exploreY].equals(Tileset.WALL)) {
                    visibleEndX += 1;
                }
                if (!tiles[visibleStartX - 1][exploreY].equals(Tileset.WALL)) {
                    visibleStartX -= 1;
                }
            }
            if (tiles[visibleStartX][exploreY - 1].equals(Tileset.WALL)
                    && tiles[visibleStartX][exploreY + 1].equals(Tileset.WALL)) {
                visibleStartX += 1;
            }
            if (tiles[visibleEndX][exploreY - 1].equals(Tileset.WALL)
                    && tiles[visibleEndX][exploreY + 1].equals(Tileset.WALL)) {
                visibleEndX -= 1;
            }
            for (int x = visibleStartX; x <= visibleEndX; x++) {
                makeTileVisible(x, exploreY);
            }
            exploreY -= 1;
        }
    }

    private long lastFrame() {
        return lastFrameTime;
    }
    private void updateFrameTime() {
        lastFrameTime = System.currentTimeMillis();
    }

    private long frameTimeDelta() {
        return System.currentTimeMillis() - lastFrameTime;
    }

    private String getTileType(int positionX, int positionY) {
        if (positionX >= 0 && positionX < width && positionY >= 0 && positionY < height) {
            if (tiles[positionX][positionY] == Tileset.FLOOR) {
                return "FLOOR";
            } else if (tiles[positionX][positionY] == Tileset.WALL) {
                return "WALL";
            } else if (tiles[positionX][positionY] == Tileset.AVATAR) {
                return "YOU";
            }
        }
        return "";
    }
    private void renderHUD() {
        StdDraw.setPenColor(255, 255, 255);
        StdDraw.text(2, height, "Tile:");
        StdDraw.text(6, height, getTileType((int) StdDraw.mouseX(), (int) StdDraw.mouseY()));
        StdDraw.text(11, height, "Restart : r");
        StdDraw.text(19, height, "Visibility: v");
        StdDraw.show();
    }

    private void makeTileVisible(int x, int y) {
        visibleTiles[x][y] = tiles[x][y];
        for (int deltaX = -1; deltaX <= 1; deltaX++) {
            for (int deltaY = -1; deltaY <= 1; deltaY++) {
                if (deltaX != deltaY && deltaX != -deltaY) {
                    if (tiles[x + deltaX][y + deltaY].equals(Tileset.WALL)) {
                        visibleTiles[x + deltaX][y + deltaY] = tiles[x + deltaX][y + deltaY];
                    }
                }
            }
        }
    }

    private void resetVisibleTiles() {
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                visibleTiles[x][y] = Tileset.NOTHING;
            }
        }
    }
}
