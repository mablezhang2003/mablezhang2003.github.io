package core;

import tileengine.TETile;
import tileengine.Tileset;


public class AutograderBuddy {

    /**
     * Simulates a game, but doesn't render anything or call any StdDraw
     * methods. Instead, returns the world that would result if the input string
     * had been typed on the keyboard.
     *
     * Recall that strings ending in ":q" should cause the game to quit and
     * save. To "quit" in this method, save the game to a file, then just return
     * the TETile[][]. Do not call System.exit(0) in this method.
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public static TETile[][] getWorldFromInput(String input) {
        String lowerCase = input.toLowerCase();
        String[] inputSplit = lowerCase.split("");
        int seed = 0;
        int lastSeedIndex = 0;
        if (inputSplit.length >= 1) {
            String[] seedArray = new String[inputSplit.length - 1];
            System.arraycopy(inputSplit, 1, seedArray, 0, inputSplit.length - 1);
            if (inputSplit[0].equals("n")) {
                for (int i = 0; i < seedArray.length - 1; i++) {
                    if (Character.isDigit((seedArray[i].charAt(0)))) {
                        int digit = Integer.parseInt(seedArray[i]);
                        seed = seed * 10 + digit;
                    }
                    if (seedArray[i + 1].equals("s")) {
                        lastSeedIndex = i;
                        break;
                    }
                }
            }
            World w = new World(90, 50);

            if (inputSplit[0].equalsIgnoreCase("l")) {
                w.loadWorldFromFile();
                for (int i = 0; i < seedArray.length; i++) {
                    if (seedArray[i].equals(":") && seedArray[i + 1].equalsIgnoreCase("Q")) {
                        w.saveWorldToFile();
                        break;
                    }
                    w.updateWorld(seedArray[i].charAt(0));
                }
            }
            if (inputSplit[0].equals("n")) {
                w.getWorldFromSeed(seed);
                for (int i = lastSeedIndex + 2; i < seedArray.length; i++) {
                    if (seedArray[i].equals(":") && seedArray[i + 1].equals("q")) {
                        w.saveWorldToFile();
                        break;
                    }
                    w.updateWorld(seedArray[i].charAt(0));
                }
            }
            return w.getTiles();
        } else {
            throw new IllegalArgumentException();
        }

    }



    /**
     * Used to tell the autograder which tiles are the floor/ground (including
     * any lights/items resting on the ground). Change this
     * method if you add additional tiles.
     */
    public static boolean isGroundTile(TETile t) {
        return t.character() == Tileset.FLOOR.character()
                || t.character() == Tileset.AVATAR.character()
                || t.character() == Tileset.FLOWER.character();
    }

    /**
     * Used to tell the autograder while tiles are the walls/boundaries. Change
     * this method if you add additional tiles.
     */
    public static boolean isBoundaryTile(TETile t) {
        return t.character() == Tileset.WALL.character()
                || t.character() == Tileset.LOCKED_DOOR.character()
                || t.character() == Tileset.UNLOCKED_DOOR.character();
    }
}
