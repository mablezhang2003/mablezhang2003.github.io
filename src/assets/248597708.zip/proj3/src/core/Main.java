package core;

import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Random r = new Random();

        long seed = r.nextInt();

        // build your own world!
        World w = new World(90, 50);
        w.runGame();
    }
}
