package core;

public class Avatar {
    private Coordinate location;
    public Avatar(int x, int y) {
        location = new Coordinate(x, y);
    }
    public int x() {
        return location.x();
    }
    public int y() {
        return location.y();
    }
    public Coordinate getLocation() {
        return location;
    }
    public void moveAvatar(int deltaX, int deltaY) {
        location.update(location.x() + deltaX, location.y() + deltaY);
    }
}
