package core;


public class WorldObject {
    private int id;
    private World.WorldObjectType type;
    private Coordinate position;
    private int width;
    private int height;
    public WorldObject(int id,
                       int x,
                       int y,
                       int width,
                       int height,
                       World.WorldObjectType t) {
        this.id = id;
        position = new Coordinate(x, y);
        this.width = width;
        this.height = height;
    }
    public int getID() {
        return id;
    }
    public Coordinate getPosition() {
        return position;
    }
    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }
}
