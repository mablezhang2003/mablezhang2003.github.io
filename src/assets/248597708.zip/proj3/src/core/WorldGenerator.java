package core;

import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import tileengine.TETile;
import tileengine.Tileset;

import java.util.ArrayList;
import java.util.Random;
import java.util.List;

public class WorldGenerator {

    public class WorldPartition {
        private Coordinate bottomLeft;
        private Coordinate topRight;
        private boolean active = false;
        private Coordinate bottomLeftRoom;
        private Coordinate topRightRoom;
        private boolean hasRoom = false;
        public WorldPartition(int x1, int y1, int x2, int y2) {
            bottomLeft = new Coordinate(x1, y1);
            topRight = new Coordinate(x2, y2);
        }
        public Coordinate bottomLeft() {
            return bottomLeft;
        }
        public Coordinate topRight() {
            return topRight;
        }
        public Coordinate getBottomLeftRoom() {
            return bottomLeftRoom;
        }
        public Coordinate getTopRightRoom() {
            return topRightRoom;
        }
        public void activate() {
            active = true;
        }
    }
    public TETile[][] generateWorld(long seed, int width, int height) {
        TETile[][] world = generateEmptyWorld(width, height);
        Random numberGen = new Random(seed);

        List<WorldPartition> partitionList = partitionWorld(numberGen, width, height);

        List<WorldObject> roomList = generateRooms(numberGen, partitionList);



        for (WorldObject room: generateRooms(numberGen, partitionList)) {
            for (int x = room.getPosition().x() - 1; x <= room.getPosition().x() + room.getWidth(); x++) {
                for (int y = room.getPosition().y() - 1; y <= room.getPosition().y() + room.getHeight(); y++) {
                    if (x == room.getPosition().x() - 1 || x == room.getPosition().x() + room.getWidth()
                            || y == room.getPosition().y() - 1 || y == room.getPosition().y() + room.getHeight()) {
                        world[x][y] = Tileset.WALL;
                    } else {
                        world[x][y] = Tileset.FLOOR;
                    }
                }
            }
        }



        List<WorldObject> hallwayList = generateHallways(numberGen, partitionList);

        drawHallways(hallwayList, world);

        return world;
    }

    private void drawHallways(List<WorldObject> hallwayList, TETile[][] world) {
        for (WorldObject hallway : hallwayList) {
            if (hallway.getPosition().x() > 0 && hallway.getPosition().y() > 0
                    && hallway.getPosition().x() + hallway.getWidth() < world.length - 1
                    && hallway.getPosition().y() + hallway.getHeight() < world[0].length - 1) {
                if (hallway.getWidth() == 1) {
                    int x = hallway.getPosition().x();
                    for (int y = hallway.getPosition().y(); y < hallway.getPosition().y() + hallway.getHeight(); y++) {
                        world[x][y] = Tileset.FLOOR;
                        if (!world[x - 1][y].equals(Tileset.FLOOR)) {
                            world[x - 1][y] = Tileset.WALL;
                        }
                        if (!world[x + 1][y].equals(Tileset.FLOOR)) {
                            world[x + 1][y] = Tileset.WALL;
                        }
                    }
                }
                if (hallway.getHeight() == 1) {
                    int y = hallway.getPosition().y();
                    for (int x = hallway.getPosition().x(); x < hallway.getPosition().x() + hallway.getWidth(); x++) {
                        world[x][y] = Tileset.FLOOR;
                        if (!world[x][y - 1].equals(Tileset.FLOOR)) {
                            world[x][y - 1] = Tileset.WALL;
                        }
                        if (!world[x][y + 1].equals(Tileset.FLOOR)) {
                            world[x][y + 1] = Tileset.WALL;
                        }
                    }
                }
            }
            /*
            System.out.print("Hallway drawn: ");
            System.out.print("(" + hallway.getPosition().x() + "," + hallway.getPosition().y() + "), ");
            System.out.println("width: " + hallway.getWidth() + " height: " + hallway.getHeight());

             */
        }
    }

    private TETile[][] generateEmptyWorld(int width, int height) {
        TETile[][] world = new TETile[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                world[x][y] = Tileset.NOTHING;
            }
        }
        return world;
    }

    private WorldObject generateRoom(Random numberGen, WorldPartition p) {
        double randomSize = 0.35 * numberGen.nextDouble() + 0.5;
        int roomWidth = (int) Math.round(randomSize * (p.topRight().x() - p.bottomLeft().x()));
        int roomHeight = (int) Math.round(randomSize * (p.topRight().y() - p.bottomLeft().y()));
        int id = Integer.parseInt((p.bottomLeft().x() + String.valueOf(p.bottomLeft().y())));
        int roomX = p.bottomLeft().x() + 1; /* fix */
        int roomY = p.bottomLeft().y() + 1; /* fix */
        p.hasRoom = true;
        p.bottomLeftRoom = new Coordinate(roomX, roomY);
        p.topRightRoom = new Coordinate(roomX + roomWidth, roomY + roomHeight);
        return new WorldObject(id, roomX, roomY, roomWidth, roomHeight, World.WorldObjectType.Room);

    }

    private List<WorldObject> generateHallway(Random numberGen, WorldPartition p1, WorldPartition p2) {
        List<WorldObject> hallwayList = new ArrayList<>();
        if (p2.getBottomLeftRoom().x() > p1.getTopRightRoom().x() /* p2 to the right of p1*/
                && p2.getBottomLeftRoom().y() < p1.getTopRightRoom().y()
                && p2.getTopRightRoom().y() > p1.getBottomLeftRoom().y()) {
            int hallwayWidth = p2.getBottomLeftRoom().x() - p1.getTopRightRoom().x();
            int hallwayHeight = 1;
            int overlapStart = Math.max(p2.getBottomLeftRoom().y(), p1.getBottomLeftRoom().y()) + 1;
            int overlapEnd = Math.min(p2.getTopRightRoom().y(), p1.getTopRightRoom().y()) - 1;
            if (overlapEnd - overlapStart > 5) {
                int hallwayX = p1.getTopRightRoom().x();
                int hallwayY = numberGen.nextInt(overlapEnd - overlapStart) + overlapStart;
                int hallwayId = Integer.parseInt(((hallwayX) + String.valueOf(hallwayY)));
                hallwayList.add(new WorldObject(hallwayId, hallwayX, hallwayY, hallwayWidth,
                        hallwayHeight, World.WorldObjectType.Hall));
            } else {
                Coordinate start = new Coordinate(
                        p1.getTopRightRoom().x(),
                        numberGen.nextInt(p1.getBottomLeftRoom().y() + 1, p1.getTopRightRoom().y() - 1)
                );
                Coordinate end = new Coordinate(
                        p2.getBottomLeftRoom().x(),
                        numberGen.nextInt(p2.getBottomLeftRoom().y() + 1, p2.getTopRightRoom().y() - 1)
                );
                hallwayList.addAll(generateTurningHallway(start, end, 'h', numberGen));
            }
        }
        if (p2.getBottomLeftRoom().y() > p1.getTopRightRoom().y() /* p2 to the top of p1*/
                && p2.getTopRightRoom().x() > p1.getBottomLeftRoom().x()
                && p2.getBottomLeftRoom().x() < p1.getTopRightRoom().x()) {
            int hallwayWidth = 1;
            int hallwayHeight = p2.getBottomLeftRoom().y() - p1.getTopRightRoom().y();
            int overlapStart = Math.max(p2.getBottomLeftRoom().x(), p1.getBottomLeftRoom().x()) + 1;
            int overlapEnd = Math.min(p2.getTopRightRoom().x(), p1.getTopRightRoom().x()) - 1;
            if (overlapEnd - overlapStart > 5) {
                int hallwayX = numberGen.nextInt(overlapEnd - overlapStart) + overlapStart;
                int hallwayY = p1.getTopRightRoom().y();
                int hallwayId = Integer.parseInt(((hallwayX) + String.valueOf(hallwayY)));
                hallwayList.add(new WorldObject(hallwayId, hallwayX, hallwayY, hallwayWidth,
                        hallwayHeight, World.WorldObjectType.Hall));
            } else {
                Coordinate start = new Coordinate(
                        numberGen.nextInt(p1.getBottomLeftRoom().x() + 1, p1.getTopRightRoom().x() - 1),
                        p1.getTopRightRoom().y()
                );
                Coordinate end = new Coordinate(
                        numberGen.nextInt(p2.getBottomLeftRoom().x() + 1, p2.getTopRightRoom().x() - 1),
                        p2.getBottomLeftRoom().y()
                );
                hallwayList.addAll(generateTurningHallway(start, end, 'v', numberGen));
            }
        }

        return hallwayList;

    }

    private List<WorldObject> generateTurningHallway(Coordinate start, Coordinate end,
                                                     char direction, Random numberGen) {
        List<WorldObject> hallwayList = new ArrayList<>();

        final int numHallways = 3;
        int prevHallwayEndX = start.x();
        int prevHallwayEndY = start.y();
        char newDirection = direction;

        for (int currentHallway = 0; currentHallway < numHallways; currentHallway++) {
            int hallwayX = 0;
            int hallwayY = 0;
            int hallwayHeight = 0;
            int hallwayWidth = 0;
            if (newDirection == 'h') {
                hallwayHeight = 1;
                if (currentHallway == 0) {
                    hallwayX = start.x();
                    hallwayY = start.y();
                    hallwayWidth = numberGen.nextInt((end.x() - start.x()) / 2) + 2;
                    prevHallwayEndX = hallwayX + hallwayWidth - 1;
                } else if (currentHallway == 1) {
                    if (start.x() < end.x()) {
                        hallwayX = prevHallwayEndX;
                        hallwayY = prevHallwayEndY;
                        hallwayWidth = end.x() - prevHallwayEndX + 1;
                    } else {
                        hallwayX = end.x();
                        hallwayY = prevHallwayEndY;
                        hallwayWidth = prevHallwayEndX - end.x() + 1;
                    }
                    prevHallwayEndX = end.x();
                } else if (currentHallway == 2) {
                    hallwayX = prevHallwayEndX;
                    hallwayY = prevHallwayEndY;
                    hallwayWidth = end.x() - prevHallwayEndX + 1;
                }
                newDirection = 'v';
            } else if (newDirection == 'v') {
                hallwayWidth = 1;
                if (currentHallway == 0) {
                    hallwayX = start.x();
                    hallwayY = start.y();
                    hallwayHeight = numberGen.nextInt((end.y() - start.y()) / 2) + 2;
                    prevHallwayEndY = hallwayY + hallwayHeight - 1;
                } else if (currentHallway == 1) {
                    if (start.y() < end.y()) {
                        hallwayX = prevHallwayEndX;
                        hallwayY = prevHallwayEndY;
                        hallwayHeight = end.y() - prevHallwayEndY + 1;
                    } else {
                        hallwayX = prevHallwayEndX;
                        hallwayY = end.y();
                        hallwayHeight = prevHallwayEndY - end.y() + 1;
                    }
                    prevHallwayEndY = end.y();
                } else if (currentHallway == 2) {
                    hallwayX = prevHallwayEndX;
                    hallwayY = prevHallwayEndY;
                    hallwayHeight = end.y() - prevHallwayEndY + 1;
                }
                newDirection = 'h';
            }
            int hallwayId = Integer.parseInt(((hallwayX) + String.valueOf(hallwayY)));
            hallwayList.add(new WorldObject(
                    hallwayId,
                    hallwayX,
                    hallwayY,
                    hallwayWidth,
                    hallwayHeight,
                    World.WorldObjectType.Hall
            ));
        }
        return hallwayList;
    }

    private boolean isConnected(WorldPartition p1, WorldPartition p2) {
        if (p1.topRight().x() + 1 == p2.bottomLeft().x()) {
            if (p1.topRight().y() >= p2.bottomLeft().y() && p1.bottomLeft().y() <= p2.topRight().y()) {
                return true;
            }
        } else if (p1.topRight().y() + 1 == p2.bottomLeft().y()) {
            if (p1.topRight().x() >= p2.bottomLeft().x() && p1.bottomLeft().x() <= p2.topRight().x()) {
                return true;
            }
        }
        return false;
    }

    public void printPartitions(List<WorldPartition> pList) {
        for (WorldPartition p : pList) {
            System.out.print("Partition: ");
            System.out.print("(" + p.bottomLeft().x() + "," + p.bottomLeft().y() + "),");
            System.out.print("(" + p.topRight().x() + "," + p.topRight().y() + ")\n");
        }
    }

    public List<WorldPartition> partitionWorld(Random numberGen, int width, int height) {
        List<WorldPartition> partitionList = new ArrayList<>();
        List<WorldPartition> partitionableList = new ArrayList<>();
        partitionableList.add(new WorldPartition(0, 0, width - 1, height - 1));
        final int minPartitions = 8;
        final int maxPartitions = 20;
        final int minPartitionSize = 10;
        final int minPartitionableSize = minPartitionSize * 2 + 1;
        final int xAxis = 0;
        final int yAxis = 1;
        int partitions = numberGen.nextInt(minPartitions, maxPartitions + 1);
        int currentPartitions = 1;
        WorldPartition toCut;
        while (currentPartitions < partitions && !partitionableList.isEmpty()) {
            toCut = partitionableList.remove(numberGen.nextInt(partitionableList.size()));
            int partitionWidth = toCut.topRight().x() - toCut.bottomLeft().x();
            int partitionHeight = toCut.topRight().y() - toCut.bottomLeft().y();
            if (partitionWidth < minPartitionableSize
                    && partitionHeight < minPartitionableSize) {
                partitionList.add(toCut);
            } else {
                int axis = numberGen.nextInt(2);
                if (partitionWidth < minPartitionableSize) {
                    axis = xAxis;
                } else if (partitionHeight < minPartitionableSize) {
                    axis = yAxis;
                }
                int cutLocation;
                WorldPartition p1;
                WorldPartition p2;
                if (axis == xAxis) {
                    cutLocation = numberGen.nextInt(minPartitionSize, partitionHeight - minPartitionSize);
                    p1 = new WorldPartition(
                            toCut.bottomLeft().x(),
                            toCut.bottomLeft().y(),
                            toCut.topRight().x(),
                            toCut.bottomLeft().y() + cutLocation
                    );
                    p2 = new WorldPartition(
                            toCut.bottomLeft().x(),
                            toCut.bottomLeft().y() + cutLocation + 1,
                            toCut.topRight().x(),
                            toCut.topRight().y()
                    );
                } else {
                    cutLocation = numberGen.nextInt(minPartitionSize, partitionWidth - minPartitionSize);
                    p1 = new WorldPartition(
                            toCut.bottomLeft().x(),
                            toCut.bottomLeft().y(),
                            toCut.bottomLeft().x() + cutLocation,
                            toCut.topRight().y()
                    );
                    p2 = new WorldPartition(
                            toCut.bottomLeft().x() + cutLocation + 1,
                            toCut.bottomLeft().y(),
                            toCut.topRight().x(),
                            toCut.topRight().y()
                    );
                }
                partitionableList.add(p1);
                partitionableList.add(p2);
                currentPartitions += 1;
            }
        }
        for (WorldPartition p : partitionableList) {
            partitionList.add(p);
        }
        return partitionList;
    }

    List<WorldObject> generateRooms(Random numberGen, List<WorldPartition> pList) {
        List<WorldObject> roomList = new ArrayList<>();
        for (WorldPartition p : pList) {
            roomList.add(generateRoom(numberGen, p));
        }
        return roomList;
    }

    List<WorldObject> generateHallways(Random numberGen, List<WorldPartition> pList) {
        List<WorldObject> hallwayList2 = new ArrayList<>();
        WeightedQuickUnionUF roomwqu = new WeightedQuickUnionUF(pList.size() + 1);
        for (int i = 0; i < pList.size(); i++) {
            for (int j = 0; j < pList.size(); j++) {
                if (isConnected(pList.get(i), pList.get(j)) && !roomwqu.connected(i, j)) {
                    List<WorldObject> newHallway = generateHallway(numberGen, pList.get(i), pList.get(j));
                    hallwayList2.addAll(newHallway);
                    if (!newHallway.isEmpty()) {
                        roomwqu.union(i, j);
                    }
                }
            }
        }
        return hallwayList2;
    }

}
