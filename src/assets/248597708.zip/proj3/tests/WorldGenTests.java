import core.AutograderBuddy;
import edu.princeton.cs.algs4.StdDraw;
import org.junit.jupiter.api.Test;
import tileengine.TERenderer;
import tileengine.TETile;
import java.util.Random;
import core.WorldGenerator;
import java.util.List;

public class WorldGenTests {
    @Test
    public void basicTest() {
        // put different seeds here to test different worlds
        TETile[][] tiles = AutograderBuddy.getWorldFromInput("N999SDDD:Q");
        tiles = AutograderBuddy.getWorldFromInput("LWWWDDD:Q");
        tiles = AutograderBuddy.getWorldFromInput("LAAAA");

        TERenderer ter = new TERenderer();
        ter.initialize(tiles.length, tiles[0].length);
        ter.renderFrame(tiles);
        StdDraw.pause(5000); // pause for 5 seconds so you can see the output
    }

    @Test
    public void basicInteractivityTest() {
        // TODO: write a test that uses an input like "n123swasdwasd"
        TETile[][] tiles = AutograderBuddy.getWorldFromInput("N999SDDDWWWDDD");
        TERenderer ter = new TERenderer();
        ter.initialize(tiles.length, tiles[0].length);
        ter.renderFrame(tiles);
        StdDraw.pause(30000);
    }

    @Test
    public void basicSaveTest() {
        // TODO: write a test that calls getWorldFromInput twice, with "n123swasd:q" and with "lwasd"
        TETile[][] tiles = AutograderBuddy.getWorldFromInput("N999SDDD:Q");
        tiles = AutograderBuddy.getWorldFromInput("LWWW:Q");
        tiles = AutograderBuddy.getWorldFromInput("LDDD:Q");
        TERenderer ter = new TERenderer();
        ter.initialize(tiles.length, tiles[0].length);
        ter.renderFrame(tiles);
        StdDraw.pause(30000);
    }

    @Test
    public void anotherSaveTest() {
        TETile[][] tiles = AutograderBuddy.getWorldFromInput("N999SDDD:Q");
        tiles = AutograderBuddy.getWorldFromInput("L:Q");
        tiles = AutograderBuddy.getWorldFromInput("L:Q");
        tiles = AutograderBuddy.getWorldFromInput("LWWWDDD");
        TERenderer ter = new TERenderer();
        ter.initialize(tiles.length, tiles[0].length);
        ter.renderFrame(tiles);
        StdDraw.pause(30000);
    }

    @Test
    public void partitionTest() {
        Random r = new Random(400);
        int width = 100;
        int height = 50;
        WorldGenerator gen = new WorldGenerator();
        List<WorldGenerator.WorldPartition> pList = gen.partitionWorld(r, width, height);

        System.out.println(pList.size());
        gen.printPartitions(pList);
    }
}
